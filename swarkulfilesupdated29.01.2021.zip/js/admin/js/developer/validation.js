/* ---------------------------------- Manage Admin User ------------------------------------------- */
/*                                                                                                  */
/* ---------------------------------- Manage Admin User ------------------------------------------- */

$(document).ready(function() {
    $('#adminUser').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
            first_name: {
                message: 'Enter first name',
                validators: {
                    notEmpty: {
                        message: 'Enter first name'
                    },
                    stringLength: {
                        max: 20,
                        message: 'The first name must be less than 20 characters'
                    }
                }
            },
			last_name: {
                message: 'Enter last name',
                validators: {
                    notEmpty: {
                        message: 'Enter last name'
                    },
                    stringLength: {
                        max: 20,
                        message: 'The last name must be less than 20 characters'
                    }
                }
            },
			phone: {
                validators: {
                    stringLength: {
                        min: 10,
                        message: 'phone number must be 10 characters'
                    }
                }
            },
			role_id: {
                validators: {
                    notEmpty: {
                        message: 'Select role'
                    }
                }
            },
			password: {
                validators: {
                    notEmpty: {
                        message: 'Enter password'
                    }
                }
            },
			email:{
                validators: {
					notEmpty: {
                        message: 'Enter email'
                    },
                    emailAddress: {
                        message: 'Enter valid email'
                    }
                }
            },
        }
    });
});

/* ---------------------------------- Manage Admin User ------------------------------------------- */
/*                                                                                                  */
/* ---------------------------------- Manage Admin User ------------------------------------------- */


$(document).ready(function() {
    $('#studentRegister').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
            name: {
                message: 'Enter student name',
                validators: {
                    notEmpty: {
                        message: 'Enter student name'
                    },
                    stringLength: {
                        max: 25,
                        message: 'Student name must be less than 25 characters'
                    }
                }
            },
			email:{
                validators: {
					notEmpty: {
                        message: 'Enter email'
                    },
                    emailAddress: {
                        message: 'Enter valid email'
                    },
					remote: {
						message: 'Email ID already exist',
						url: appUrl +'/userEmailValidate',
						data: {
							'email':$('input[name="email"]'),
							'user_id':$('input[name="id"]').val(),
							'_token':$('input[name="_token"]').val()
							},
						type: 'POST'
					}
                }
            },
			phone: {
                validators: {
					notEmpty: {
                        message: 'Enter Phone No.'
                    },
                    stringLength: {
                        min: 10,
                        message: 'Invalid Phone No.'
                    }
                }
            },
			code: {
                validators: {
					notEmpty: {
                        message: 'Empty'
                    },
                    stringLength: {
                        max: 2,
                        message: 'country code must be 2 characters'
                    }
                }
            },
			password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
						
							var pwd = value;
							var c_pwd = validator.getFieldElements('confirm_password').val();
							var focus = $('[name="password"]').is(':focus');
							
							if (pwd == '') {
								return {
									valid: false,
									message: 'Enter password'
								};
							}
							else if (focus == true && c_pwd != '' && pwd != c_pwd) {
								return {
									valid: false,
									message: ''
								};
							}
							
							return true;
						}
					}
                }
            },
			confirm_password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
							var pwd = validator.getFieldElements('password').val();
							var c_pwd = value;
							
								if (c_pwd == '') {
									return {
										valid: false,
										message: 'Enter your Confirm password'
									};
								}
								else if (c_pwd.length < 8) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}else if (c_pwd == c_pwd.toLowerCase()) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}else if (c_pwd.search(/[0-9]/) < 0) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}
								else if ($('[name="confirm_password"]').is(':focus') == true && pwd != '' && pwd != c_pwd) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}
								return true;
							
								
						}
					}
				}
            },
			
			address_1: {
                validators: {
                    notEmpty: {
                        message: 'Enter Address 1'
                    }
                }
            },
			dob: {
                validators: {
                    notEmpty: {
                        message: 'Select dob'
                    }
                }
            },
			state: {
                validators: {
                    notEmpty: {
                        message: 'Enter State'
                    }
                }
            },
			city: {
                validators: {
                    notEmpty: {
                        message: 'Enter City'
                    }
                }
            },
			zip_code: {
                validators: {
                    notEmpty: {
                        message: 'Enter Zip code'
                    }
                }
            },
			country: {
                validators: {
                    notEmpty: {
                        message: 'Enter Country'
                    }
                }
            },
        }
    });
});


$(document).ready(function() {
    $('#studentEdit').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
            name: {
                message: 'Enter student name',
                validators: {
                    notEmpty: {
                        message: 'Enter student name'
                    },
                    stringLength: {
                        max: 25,
                        message: 'Student name must be less than 25 characters'
                    }
                }
            },
			email:{
                validators: {
					notEmpty: {
                        message: 'Enter email'
                    },
                    emailAddress: {
                        message: 'Enter valid email'
                    },
					remote: {
						message: 'Email ID already exist',
						url: appUrl +'/userEmailValidate',
						data: {
							'email':$('input[name="email"]'),
							'user_id':$('input[name="id"]').val(),
							'_token':$('input[name="_token"]').val()
							},
						type: 'POST'
					}
                }
            },
			phone: {
                validators: {
					notEmpty: {
                        message: 'Enter Phone No.'
                    },
                    stringLength: {
                        min: 10,
                        message: 'Invalid Phone No.'
                    }
                }
            },
			code: {
                validators: {
					notEmpty: {
                        message: 'Empty'
                    },
                    stringLength: {
                        max: 2,
                        message: 'country code must be 2 characters'
                    }
                }
            },
			
			address_1: {
                validators: {
                    notEmpty: {
                        message: 'Enter Address 1'
                    }
                }
            },
			dob: {
                validators: {
                    notEmpty: {
                        message: 'Select dob'
                    }
                }
            },
			state: {
                validators: {
                    notEmpty: {
                        message: 'Enter State'
                    }
                }
            },
			city: {
                validators: {
                    notEmpty: {
                        message: 'Enter City'
                    }
                }
            },
			zip_code: {
                validators: {
                    notEmpty: {
                        message: 'Enter Zip code'
                    }
                }
            },
			country: {
                validators: {
                    notEmpty: {
                        message: 'Enter Country'
                    }
                }
            },
        }
    });
});

$(document).on('change','input[name="dob"]',function(){
	$('#studentRegister').bootstrapValidator('revalidateField', 'dob');
});


$(document).ready(function() {
    $('#forgotPassword').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
			email:{
                validators: {
					notEmpty: {
                        message: 'Enter email'
                    },
                    emailAddress: {
                        message: 'Enter valid email'
                    },
					remote: {
						message: 'Email id not already exist',
						url: appUrl +'/userEmailCheck',
						data: {
							'email':$('input[name="email"]'),
							'user_id':$('input[name="id"]').val(),
							'_token':$('input[name="_token"]').val()
							},
						type: 'POST'
					}
            }
        }
	}

   });
});


$(document).ready(function() {
    $('#teacherRegister').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
            name: {
                message: 'Enter teacher name',
                validators: {
                    notEmpty: {
                        message: 'Enter teacher name'
                    },
                    stringLength: {
                        max: 25,
                        message: 'teacher name must be less than 25 characters'
                    }
                }
            },
			email:{
                validators: {
					notEmpty: {
                        message: 'Enter email'
                    },
                    emailAddress: {
                        message: 'Enter valid email'
                    },
					remote: {
						message: 'Email ID already exist',
						url: appUrl +'/userEmailValidate',
						data: {
							'email':$('input[name="email"]'),
							'user_id':$('input[name="id"]').val(),
							'_token':$('input[name="_token"]').val()
							},
						type: 'POST'
					}
                }
            },
			phone: {
                validators: {
					notEmpty: {
                        message: 'Enter Phone No.'
                    },
                    stringLength: {
                        min: 10,
                        message: 'Invalid Phone No.'
                    }
                }
            },
			code: {
                validators: {
					notEmpty: {
                        message: 'Empty'
                    },
                    stringLength: {
                        max: 2,
                        message: 'country code must be 2 characters'
                    }
                }
            },
			password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
						
							var pwd = value;
							var c_pwd = validator.getFieldElements('confirm_password').val();
							var focus = $('[name="password"]').is(':focus');
							
							if (pwd == '') {
								return {
									valid: false,
									message: 'Enter password'
								};
							}
							else if (focus == true && c_pwd != '' && pwd != c_pwd) {
								return {
									valid: false,
									message: ''
								};
							}
							
							return true;
						}
					}
                }
            },
			confirm_password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
							var pwd = validator.getFieldElements('password').val();
							var c_pwd = value;
							
								if (c_pwd == '') {
									return {
										valid: false,
										message: 'Enter your Confirm password'
									};
								}
								else if (c_pwd.length < 8) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}else if (c_pwd == c_pwd.toLowerCase()) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}else if (c_pwd.search(/[0-9]/) < 0) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}
								else if ($('[name="confirm_password"]').is(':focus') == true && pwd != '' && pwd != c_pwd) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}
								return true;
							
								
						}
					}
				}
            },
			
			address_1: {
                validators: {
                    notEmpty: {
                        message: 'Enter Address 1'
                    }
                }
            },
			state: {
                validators: {
                    notEmpty: {
                        message: 'Enter State'
                    }
                }
            },
			city: {
                validators: {
                    notEmpty: {
                        message: 'Enter City'
                    }
                }
            },
			zipcode: {
                validators: {
                    notEmpty: {
                        message: 'Enter Zip code'
                    }
                }
            },
			country: {
                validators: {
                    notEmpty: {
                        message: 'Enter Country'
                    }
                }
            },
        }
    });
});



$(document).ready(function() {
    $('#changePassword').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
			password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
						
							var pwd = value;
							var c_pwd = validator.getFieldElements('confirm_password').val();
							var focus = $('[name="password"]').is(':focus');
							
							if (pwd == '') {
								return {
									valid: false,
									message: 'Enter password'
								};
							}
							else if (focus == true && c_pwd != '' && pwd != c_pwd) {
								return {
									valid: false,
									message: ''
								};
							}
							
							return true;
						}
					}
                }
            },
			confirm_password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
							var pwd = validator.getFieldElements('password').val();
							var c_pwd = value;
								if(pwd != ''){
									if (c_pwd == '') {
										return {
											valid: false,
											message: 'Enter your Confirm password'
										};
									}
									else if (c_pwd.length < 8) {
										return {
											valid: false,
											message: 'Password does not match'
										};
									}else if (c_pwd == c_pwd.toLowerCase()) {
										return {
											valid: false,
											message: 'Password does not match'
										};
									}else if (c_pwd.search(/[0-9]/) < 0) {
										return {
											valid: false,
											message: 'Password does not match'
										};
									}
									else if ($('[name="confirm_password"]').is(':focus') == true && pwd != '' && pwd != c_pwd) {
										return {
											valid: false,
											message: 'Password does not match'
										};
									}
								}
								return true;
							
								
						}
					}
				}
            }
        }
    });
});

$(document).ready(function() {
    $('#teacherEditRegister').bootstrapValidator({
        message: 'This value is not valid',
        feedbackIcons: {
            valid: '',
            invalid: '',
            validating: ''
        },
		excluded: [':disabled'],
        fields: {
            name: {
                message: 'Enter teacher name',
                validators: {
                    notEmpty: {
                        message: 'Enter teacher name'
                    },
                    stringLength: {
                        max: 25,
                        message: 'teacher name must be less than 25 characters'
                    }
                }
            },
			email:{
                validators: {
					notEmpty: {
                        message: 'Enter email'
                    },
                    emailAddress: {
                        message: 'Enter valid email'
                    },
					remote: {
						message: 'Email ID already exist',
						url: appUrl +'/userEmailValidate',
						data: {
							'email':$('input[name="email"]'),
							'user_id':$('input[name="id"]').val(),
							'_token':$('input[name="_token"]').val()
							},
						type: 'POST'
					}
                }
            },
			phone: {
                validators: {
					notEmpty: {
                        message: 'Enter Phone No.'
                    },
                    stringLength: {
                        min: 10,
                        message: 'Invalid Phone No.'
                    }
                }
            },
			code: {
                validators: {
					notEmpty: {
                        message: 'Empty'
                    },
                    stringLength: {
                        max: 2,
                        message: 'country code must be 2 characters'
                    }
                }
            },
			password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
						
							var pwd = value;
							var c_pwd = validator.getFieldElements('confirm_password').val();
							var focus = $('[name="password"]').is(':focus');
							
							if (focus == true && c_pwd != '' && pwd != c_pwd) {
								return {
									valid: false,
									message: ''
								};
							}
							
							return true;
						}
					}
                }
            },
			confirm_password: {
                validators: {
					callback: {
						message: '',
						callback: function (value, validator) {
							var pwd = validator.getFieldElements('password').val();
							var c_pwd = value;
							if(pwd != ''){
								if (c_pwd == '') {
									return {
										valid: false,
										message: 'Enter your Confirm password'
									};
								}
								else if (c_pwd.length < 8) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}else if (c_pwd == c_pwd.toLowerCase()) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}else if (c_pwd.search(/[0-9]/) < 0) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}
								else if ($('[name="confirm_password"]').is(':focus') == true && pwd != '' && pwd != c_pwd) {
									return {
										valid: false,
										message: 'Password does not match'
									};
								}
								return true;
							
							}else{
								return true;
							}
						}
					}
				}
            },
			
			address_1: {
                validators: {
                    notEmpty: {
                        message: 'Enter Address 1'
                    }
                }
            },
			state: {
                validators: {
                    notEmpty: {
                        message: 'Enter State'
                    }
                }
            },
			city: {
                validators: {
                    notEmpty: {
                        message: 'Enter City'
                    }
                }
            },
			zipcode: {
                validators: {
                    notEmpty: {
                        message: 'Enter Zip code'
                    }
                }
            },
			country: {
                validators: {
                    notEmpty: {
                        message: 'Enter Country'
                    }
                }
            },
        }
    });
});